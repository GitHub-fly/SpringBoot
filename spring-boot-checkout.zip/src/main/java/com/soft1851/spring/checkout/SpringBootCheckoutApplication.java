package com.soft1851.spring.checkout;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootCheckoutApplication {

    public static void main(String[] args) {
        SpringApplication.run(SpringBootCheckoutApplication.class, args);
    }

}
