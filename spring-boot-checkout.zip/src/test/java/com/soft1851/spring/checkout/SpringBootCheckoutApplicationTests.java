package com.soft1851.spring.checkout;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootCheckoutApplicationTests {

    @Test
    void contextLoads() {
    }

}
